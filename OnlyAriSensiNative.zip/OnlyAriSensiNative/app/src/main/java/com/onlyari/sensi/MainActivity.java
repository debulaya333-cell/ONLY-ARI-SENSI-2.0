package com.onlyari.sensi;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 701;
    private WebView web;
    private boolean waitingToEnter = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new StartBridge(), "OnlyAriNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class StartBridge {
        @JavascriptInterface public void startApp() {
            runOnUiThread(() -> enterApp());
        }
        @JavascriptInterface public void joinTelegram() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/onlyari9999"))); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Telegram link unavailable", Toast.LENGTH_SHORT).show(); }
            });
        }
    }

    private void enterApp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            waitingToEnter = true;
            Toast.makeText(this, "Allow Display over other apps to show the floating icon.", Toast.LENGTH_LONG).show();
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, OVERLAY_REQUEST);
        } else {
            showMainAndOverlay();
        }
    }

    private void showMainAndOverlay() {
        waitingToEnter = false;
        if (web != null) web.evaluateJavascript("showMainApp()", null);
        Intent service = new Intent(this, FloatingOverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
        else startService(service);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST && waitingToEnter) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) showMainAndOverlay();
            else Toast.makeText(this, "Permission not allowed. Tap START and allow it to continue.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onBackPressed() { moveTaskToBack(true); }
}
